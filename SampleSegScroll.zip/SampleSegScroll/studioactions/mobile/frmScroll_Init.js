function frmScroll_Init(eventobject) {
    return AS_Form_bd19de4e02ad455b945dfc6b432408d0(eventobject);
}

function AS_Form_bd19de4e02ad455b945dfc6b432408d0(eventobject) {
    return formInit.call(this);
}