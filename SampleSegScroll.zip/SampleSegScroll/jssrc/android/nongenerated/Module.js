function formInit() {
    var data = [{
        lblScroll: "Some Label 0"
    }, {
        lblScroll: "Some Label 1"
    }, {
        lblScroll: "Some Label 2"
    }, {
        lblScroll: "Some Label 3"
    }, {
        lblScroll: "Some Label 4"
    }, {
        lblScroll: "Some Label 5"
    }, {
        lblScroll: "Some Label 6"
    }, {
        lblScroll: "Some Label 7"
    }, {
        lblScroll: "Some Label 8"
    }, {
        lblScroll: "Some Label 9"
    }, {
        lblScroll: "Some Label 10"
    }, {
        lblScroll: "Some Label 11"
    }, {
        lblScroll: "Some Label 12"
    }, {
        lblScroll: "Some Label 13"
    }, {
        lblScroll: "Some Label 14"
    }, {
        lblScroll: "Some Label 15"
    }, {
        lblScroll: "Some Label 16"
    }, {
        lblScroll: "Some Label 17"
    }, {
        lblScroll: "Some Label 18"
    }, {
        lblScroll: "Some Label 19"
    }, {
        lblScroll: "Some Label 20"
    }, {
        lblScroll: "Some Label 21"
    }];
    frmSegScroll.segScroll.setData(data);
    frmSegScroll.flxSegScroll.forceLayout();
    frmSegScroll.btnScroll.onClick = function() {
        scrollToRow();
    };
}
var index = 16;

function scrollToRow() {
    try {
        kony.print("Inside scrollToRow");
        var yOffset = 50 * index;
        var contentOffset = {
            "x": "0dp",
            "y": yOffset + "dp"
        };
        frmSegScroll.flxSegScroll.setContentOffset(contentOffset, false);
        frmSegScroll.flxSegScroll.forceLayout();
    } catch (ex) {
        kony.print("Exception is : " + ex);
    }
}