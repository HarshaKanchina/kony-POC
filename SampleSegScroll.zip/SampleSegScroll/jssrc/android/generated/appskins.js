function skinsInit() {
    defBtnFocus = "defBtnFocus";
    defBtnNormal = "defBtnNormal";
    defLabel = "defLabel";
    seg2Focus = "seg2Focus";
    seg2Normal = "seg2Normal";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slFbox = "slFbox";
    slForm = "slForm";
    slFSbox = "slFSbox";
    sliPhoneSegmentHeader = "sliPhoneSegmentHeader";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};