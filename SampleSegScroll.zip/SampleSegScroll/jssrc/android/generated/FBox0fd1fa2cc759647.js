function initializeFBox0fd1fa2cc759647() {
    FBox0fd1fa2cc759647 = new kony.ui.FlexContainer({
        "clipBounds": false,
        "height": "40dp",
        "id": "FBox0fd1fa2cc759647",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {
        "containerWeight": 100
    }, {});
    FBox0fd1fa2cc759647.setDefaultUnit(kony.flex.DP);
    FBox0fd1fa2cc759647.add();
}