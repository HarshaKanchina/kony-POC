function addWidgetsfrmSegScroll() {
    frmSegScroll.setDefaultUnit(kony.flex.DP);
    var flxSegScroll = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "contentOffset": {
            "x": "10dp",
            "y": "22dp"
        },
        "enableScrolling": true,
        "height": "50%",
        "horizontalScrollIndicator": true,
        "id": "flxSegScroll",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "25%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSegScroll.setDefaultUnit(kony.flex.DP);
    var segScroll = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "data": [{
            "lblScroll": "Label"
        }, {
            "lblScroll": "Label"
        }, {
            "lblScroll": "Label"
        }],
        "groupCells": false,
        "id": "segScroll",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxScrollTemplate,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxScrollTemplate": "flxScrollTemplate",
            "lblScroll": "lblScroll"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSegScroll.add(segScroll);
    var btnScroll = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "btnScroll",
        "isVisible": true,
        "left": "67dp",
        "skin": "defBtnNormal",
        "text": "SCROLL",
        "top": "626dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmSegScroll.add(flxSegScroll, btnScroll);
};

function frmSegScrollGlobals() {
    frmSegScroll = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmSegScroll,
        "enabledForIdleTimeout": false,
        "id": "frmSegScroll",
        "init": AS_Form_bd19de4e02ad455b945dfc6b432408d0,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};